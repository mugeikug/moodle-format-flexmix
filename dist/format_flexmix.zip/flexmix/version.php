<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version details for format_flexmix.
 *
 * @package     format_flexmix
 * @copyright   2026 Hiroki Maezawa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'format_flexmix';
$plugin->version   = 2026081200;
$plugin->requires  = 2021051700; // Moodle 3.11.0.
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1.0';
// Declared supported branch range: 3.11 (311) through 4.1 (401).
// This is a compatibility declaration only; verify against newer branches before relying on it.
$plugin->supported = [311, 401];
